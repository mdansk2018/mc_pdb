# Defining the functions #

# add
# subtract
# multiply
# divide
# power
# square root
# squared
# cubed
# cosine
# factorial

# ADD

add <- function(x, y){
  return(x + y)
}


# Subtract

subtract <- function(x, y){
  return(x - y)
}


# Multiply

multiply <- function(x, y){
  return(x * y)
}


# Divide

divide <- function(x, y){
  return(x / y)
}


# Power

power <- function(x, y){
  return(x**y)
}


# Square Root

squareroot <- function(x){
  return (sqrt(x))
}


# Squared

squared <- function(x){
  return(x*x)
}


# Cubed

cubed <- function(x){
  return(x*x*x)
}

# Cosine

cosine <- function(x){
  return (cos(x))
}


# Factorial

factorial <- function(x){
  if (x == 0)
    return (1)
  else
    return (x * factorial(x - 1))
}

# Calling the functions

add(1, 10)
subtract(5, 2)
multiply(10, 10)
divide(100, 25)
power(10, 2)
squareroot(100)
squared(4)
cubed(3)
cosine(3)
factorial(3)