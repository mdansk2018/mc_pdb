
# importing numpy and pandas
from collections import Counter

import numpy as np
import pandas as pd
from pandas import Series,DataFrame

import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('whitegrid')




# load the 'changes' file which we are going analyse

an_file = pd.read_csv('workingfileV2.csv')


# I now want to take a look at the first few rows to see what might be interesting
print (an_file[0:5])
an_file.info()


# basic visualisation
# As per my word doc on data prep the first thing that is catching my eye is the "comment" column.

# putting time into a simple bar chart.
labels, values = zip(*Counter(an_file['time']).items())

indexes = np.arange(len(labels))
width = 0.5

plt.bar(indexes, values, width)
plt.xticks(indexes + width * 0.1, labels)
plt.ylabel('Process Changes')
plt.xlabel('Time (hour)')
plt.title('Process Changes by Time')
plt.show()


# let's look at the date

labels, values = zip(*Counter(an_file['date']).items())

indexes = np.arange(len(labels))
width = 0.5

plt.bar(indexes, values, width)
plt.xticks(indexes + width * 0.1, labels)
plt.ylabel('Process Changes')
plt.xlabel('Date')
plt.title('Process Changes by Month')
plt.show()

# let's look at authors

labels, values = zip(*Counter(an_file['author']).items())

indexes = np.arange(len(labels))
width = 0.5

plt.bar(indexes, values, width)
plt.xticks(indexes + width * 0.1, labels)
plt.ylabel('Process Changes')
plt.xlabel('Author')
plt.title('Process Changes by Author')
plt.show()




# putting the authors into a simple bar chart.
labels, values = zip(*Counter(an_file['comment']).items())

indexes = np.arange(len(labels))
width = 0.5

plt.bar(indexes, values, width)
plt.xticks(indexes + width * 0.1, labels)
plt.show()

sns.factorplot('time','author', data=an_file,size=4,aspect=3)


fig, (axis1, axis2, axis3) = plt.subplots(1,3,figsize = (15,5))
sns.countplot(x = 'time', data = an_file, ax = axis1)
sns.countplot(x = 'author', hue = "time", data = an_file, order = [1,0], ax = axis2)

# I want to see what time most of the comments clustered around
fig, axis1 = plt.subplots(1,1,figsize=(18,4))
time_group = an_file[["time", "comment"]].groupby(['time'],as_index=False).mean()
sns.barplot(x='comment', y='time', data=time_group)



