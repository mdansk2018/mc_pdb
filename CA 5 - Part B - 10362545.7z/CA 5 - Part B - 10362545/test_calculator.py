import unittest
import math

from calculator import Calculator

# Test list
a = [1, 2, 3]
b = [4, 5, 6]
c = [7, 8, 9]

# test the calculator functionality
class TestCalculator(unittest.TestCase):

    def setUp(self):
        self.calc = Calculator()


    def test_calculator_add_method_returns_correct_result(self):
        result = self.calc.add(a)
        self.assertEqual(6, result)
        result = self.calc.add(b)
        self.assertEqual(15, result)
        result = self.calc.add(c)
        self.assertEqual(24, result)

    def test_calculator_subtract_method_returns_correct_result(self):
        result = self.calc.subtract(a)
        self.assertEqual(-4, result)
        result = self.calc.subtract(b)
        self.assertEqual(-7, result)
        result = self.calc.subtract(c)
        self.assertEqual(-10, result)
        
    def test_calculator_multiply_method_returns_correct_result(self):
        result = self.calc.multiply(a)
        self.assertEqual(6, result)
        result = self.calc.multiply(b)
        self.assertEqual(120, result)
        result = self.calc.multiply(c)
        self.assertEqual(504, result)      
        
    def test_calculator_divide_method_returns_correct_result(self):
        result = self.calc.divide(a)
        self.assertEqual(0, result)
        result = self.calc.divide(b)
        self.assertEqual(0, result)
        result = self.calc.divide(c)
        self.assertEqual(0, result)  
        
    def test_calculator_power_returns_correct_result(self):
        result = self.calc.power(a)
        self.assertEqual([1.0, 1.0, 1.0, 2.0, 4.0, 8.0, 3.0, 9.0, 27.0], result)
        result = self.calc.power(b)
        self.assertEqual([256.0, 1024.0, 4096.0, 625.0, 3125.0, 15625.0, 1296.0, 7776.0, 46656.0], result)
        result = self.calc.power(c)
        self.assertEqual([823543.0, 5764801.0, 40353607.0, 2097152.0, 16777216.0, 134217728.0, 4782969.0, 43046721.0, 387420489.0], result)  
        
    def test_calculator_square_root_method_returns_correct_result(self):
        result = self.calc.squareroot(a)
        self.assertEqual([1.0, 1.4142135623730951, 1.7320508075688772], result)
        result = self.calc.squareroot(b)
        self.assertEqual([2.0, 2.23606797749979, 2.449489742783178], result)
        result = self.calc.squareroot(c)
        self.assertEqual([2.6457513110645907, 2.8284271247461903, 3.0], result) 
  
    def test_calculator_squared_method_returns_correct_result(self):
        result = self.calc.squared(a)
        self.assertEqual([1, 4, 9], result)
        result = self.calc.squared(b)
        self.assertEqual([16, 25, 36], result)
        result = self.calc.squared(c)
        self.assertEqual([49, 64, 81], result)
        
    def test_calculator_cubed_method_returns_correct_result(self):
        result = self.calc.cubed(a)
        self.assertEqual([1, 8, 27], result)
        result = self.calc.cubed(b)
        self.assertEqual([64, 125, 216], result)
        result = self.calc.cubed(c)
        self.assertEqual([343, 512, 729], result)  
        
    def test_calculator_cosine_returns_correct_result(self):
        result = self.calc.cosine(a)
        self.assertEqual([0.5403023058681397, -0.4161468365471424, -0.9899924966004454], result)        
        result = self.calc.cosine(b)
        self.assertEqual([-0.6536436208636119, 0.28366218546322625, 0.960170286650366], result)   
        result = self.calc.cosine(c)
        self.assertEqual([0.7539022543433046, -0.14550003380861354, -0.9111302618846769], result)

    def test_calculator_factorial_returns_correct_result(self):
        result = self.calc.factorial(a)
        self.assertEqual([1, 2, 6], result)    
        result = self.calc.factorial(b)
        self.assertEqual([24, 120, 720], result)        
        result = self.calc.factorial(c)
        self.assertEqual([5040, 40320, 362880], result)   

if __name__ == '__main__':
    unittest.main()
