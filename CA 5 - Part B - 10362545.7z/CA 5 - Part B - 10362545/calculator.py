import math

class Calculator(object):
   
    def add(self, f):
        result = reduce(lambda x,y: x+y, f)
        return result

    def subtract(self, f):
        result = reduce(lambda x,y: x-y, f)
        return result
           
    def multiply(self, f):
        result = reduce(lambda x,y: x*y, f)
        return result   

    def divide(self, f):
        result = reduce(lambda x,y: x/y, f)
        return result    

    def power(self, f):
        result = [math.pow(x,y) for x in f for y in f]
        return result 

    def squareroot(self, f):
        result = [math.sqrt(x) for x in f]
        return result

    def squared(self, f):
        result = [(x*x) for x in f]
        return result

    def cubed(self, f):
        result = [(x*x*x) for x in f]
        return result  

    def cosine(self, f):
        result = [math.cos(x) for x in f]
        return result  

    def factorial(self, f):
        result = [math.factorial(x) for x in f]
        return result
    



